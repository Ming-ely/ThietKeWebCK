let subtotal = 300000;  
let shippingFee = 30000;
let discount = 0;

function updateView() {
    document.getElementById("subtotal").textContent = subtotal + "đ";
    document.getElementById("shipping").textContent = shippingFee + "đ";
    document.getElementById("discount").textContent = "-" + discount + "đ";
    document.getElementById("total").textContent = (subtotal + shippingFee - discount) + "đ";
}

function applyVoucher() {
    const code = document.getElementById("voucherInput").value.toUpperCase();

    discount = 0;
    shippingFee = 30000;

    if (code === "BOOK10") {
        discount = Math.min(subtotal * 0.1, 50000);
    }
    if (code === "SHIPFREE" && subtotal >= 200000) {
        shippingFee = 0;
    }

    updateView();
}

function goCheckout() {
    localStorage.setItem("subtotal", subtotal);
    localStorage.setItem("shippingFee", shippingFee);
    localStorage.setItem("discount", discount);
    localStorage.setItem("total", subtotal + shippingFee - discount);

    window.location.href = "checkout.html";
}

updateView();
