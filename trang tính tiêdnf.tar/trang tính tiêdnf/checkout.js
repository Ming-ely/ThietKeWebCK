function renderCheckout() {
    const subtotal = localStorage.getItem("subtotal") || 0;
    const ship = localStorage.getItem("shippingFee") || 0;
    const discount = localStorage.getItem("discount") || 0;
    const total = localStorage.getItem("total") || 0;

    document.getElementById("coSubtotal").textContent = subtotal + "đ";
    document.getElementById("coShip").textContent = ship + "đ";
    document.getElementById("coDiscount").textContent = "-" + discount + "đ";
    document.getElementById("coTotal").textContent = total + "đ";
}

renderCheckout();
