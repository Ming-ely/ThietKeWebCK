// Dữ liệu giả lập sản phẩm


// Render products trên index
function renderProducts(){
const grid = document.getElementById('productGrid');
if(!grid) return;
grid.innerHTML = '';
PRODUCTS.forEach(p=>{
const card = document.createElement('div'); card.className='card';
card.innerHTML = `
<img src="${p.img}" alt="${p.title}">
<h4>${p.title}</h4>
<p class="price">${fmt(p.price)}</p>
<div class="actions">
<button class="primary" onclick="addToCart(${p.id})">Mua ngay</button>
<button onclick="addToCart(${p.id})">Thêm vào giỏ</button>
</div>
`;
grid.appendChild(card);
});
}


// Cart page UI
function loadCartUI(){
const area = document.getElementById('cartArea');
if(!area) return;
let cart = getCart();
if(cart.length===0){ area.innerHTML = '<p>Giỏ hàng trống.</p>'; document.querySelector('.cart-summary').style.display='block'; updateTotals(); return }


area.innerHTML = '';
cart.forEach(item=>{
const div = document.createElement('div'); div.className='cart-item';
div.innerHTML = `
<img src="${item.img}" alt="${item.title}">
<div style="flex:1">
<div style="font-weight:600">${item.title}</div>
<div class="qty">
<button onclick="changeQty(${item.id}, -1)">-</button>
<span id="qty-${item.id}">${item.qty}</span>
<button onclick="changeQty(${item.id}, 1)">+</button>
<button style="margin-left:12px;color:red;background:none;border:none;cursor:pointer" onclick="removeItem(${item.id})">Xóa</button>
</div>
</div>
<div style="text-align:right">
<div>${fmt(item.price)}</div>
<div>${fmt(item.price * item.qty)}</div>
</div>
`;
area.appendChild(div);
});
// Event voucher apply
document.getElementById('applyVoucher').onclick = ()=>{ applyVoucherCode(); }
document.getElementById('toCheckout').onclick = ()=>{ window.location.href='checkout.html'; }
updateTotals();
}


function changeQty(id, delta){}
let cart = g